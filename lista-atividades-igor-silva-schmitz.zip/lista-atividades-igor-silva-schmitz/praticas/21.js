// 21. Ainda sobre o endpoint criado na atividade 20, vamos criar um middleware que valide o
// corpo da requisição POST /ticket.
// Exemplo: No corpo da requisição, no body, estão vindo os campos: título, prioridade,
// descrição, categoria, nome solicitante, departamento/setor do solicitante, telefone e email
// do solicitante.

